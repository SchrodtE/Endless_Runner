# Endless_Runner
A runner that is endless for DAGD 355

Bryan:

Jordan:

Tim:

Eric:
AI


List of Assets    
(Human Health) - Blood Bag  ✓
(Monster Health - ^   ✓
(Human-ify Pickup) - Vial   ✓
(Human-ify Pickup) - Syringe   ✓
(Human-ify Pickup) - Pill Bottle   ✓
(Monster-ify Pickup) - Brain   X
(Monster-ify Pickup) - Any Limb  ✓
(Monster-ify Pickup) - Any Organ   X
(Item Pickup) - Machete Bike   ✓
(Item Pickup) - Balloons   ✓
(Item Pickup) - Coffee   ✓
(Mutation Pickup) - Whatever makes Muscle Legs  ✓
(Mutation Pickup) - Whatever makes Bunny Ears   X
(Mutation Pickup) - Whatever makes Acid Spit   ✓
(NPC Character) - Human  X
(NPC Character) - Monster  X
(Main Character) - Andyogynous Person  ✓
